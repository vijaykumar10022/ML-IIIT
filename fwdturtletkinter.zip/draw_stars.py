#Drawing stars
import turtle
t = turtle.Pen()
for x in range(1, 9):
    t.forward(100)
    t.left(225)
