from tkinter import * 
tk = Tk()
btn = Button(tk, text="click me")
btn.pack()
