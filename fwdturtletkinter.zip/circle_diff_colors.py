import turtle
t = turtle.Pen()
def mycircle(red, green, blue):
    t.color(red, green, blue)
    t.begin_fill()
    t.circle(50)
    t.end_fill()
mycircle(0, 1, 0)#green
mycircle(0, 0.5, 0)#dark green
mycircle(1, 0, 0)#red
mycircle(0.5, 0, 0)#brown
mycircle(0, 0, 1)#blue
mycircle(0, 0, 0.5)#dark blue
mycircle(0.9, 0.75, 0)#dark yellow
mycircle(1, 0.7, 0.75)#light pink
mycircle(1, 0.5, 0)#orange
mycircle(0.9, 0.5, 0.15)#dark ornage
mycircle(0, 0, 0)#black




