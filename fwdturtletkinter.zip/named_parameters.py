def person(width, height):
    print('I am %s feet wide, %s feet high' % (width, height))
person(2, 5)    
