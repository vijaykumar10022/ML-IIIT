import turtle
turtle.setup(width=500, height=500)
t = turtle.Pen()
t.up()
t.goto(-250, 250)
t.down()
t.goto(500, -500)
